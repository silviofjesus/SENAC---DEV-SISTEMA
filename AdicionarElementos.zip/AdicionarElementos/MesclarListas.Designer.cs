﻿namespace AdicionarElementos
{
    partial class MesclarListas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonLista01 = new System.Windows.Forms.Button();
            this.buttonLista02 = new System.Windows.Forms.Button();
            this.buttonMesclarListas = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonLista01
            // 
            this.buttonLista01.Location = new System.Drawing.Point(42, 56);
            this.buttonLista01.Name = "buttonLista01";
            this.buttonLista01.Size = new System.Drawing.Size(75, 23);
            this.buttonLista01.TabIndex = 0;
            this.buttonLista01.Text = "Lista01";
            this.buttonLista01.UseVisualStyleBackColor = true;
            this.buttonLista01.Click += new System.EventHandler(this.buttonLista01_Click);
            // 
            // buttonLista02
            // 
            this.buttonLista02.Location = new System.Drawing.Point(43, 107);
            this.buttonLista02.Name = "buttonLista02";
            this.buttonLista02.Size = new System.Drawing.Size(75, 23);
            this.buttonLista02.TabIndex = 1;
            this.buttonLista02.Text = "Lista02";
            this.buttonLista02.UseVisualStyleBackColor = true;
            this.buttonLista02.Click += new System.EventHandler(this.buttonLista02_Click);
            // 
            // buttonMesclarListas
            // 
            this.buttonMesclarListas.Location = new System.Drawing.Point(43, 162);
            this.buttonMesclarListas.Name = "buttonMesclarListas";
            this.buttonMesclarListas.Size = new System.Drawing.Size(75, 23);
            this.buttonMesclarListas.TabIndex = 2;
            this.buttonMesclarListas.Text = "Mesclar Listas";
            this.buttonMesclarListas.UseVisualStyleBackColor = true;
            this.buttonMesclarListas.Click += new System.EventHandler(this.buttonMesclarListas_Click);
            // 
            // MesclarListas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonMesclarListas);
            this.Controls.Add(this.buttonLista02);
            this.Controls.Add(this.buttonLista01);
            this.Name = "MesclarListas";
            this.Text = "MesclarListas";
            this.ResumeLayout(false);

        }

        #endregion

        private Button buttonLista01;
        private Button buttonLista02;
        private Button buttonMesclarListas;
    }
}