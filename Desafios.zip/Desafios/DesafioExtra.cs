﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desafios
{
    public partial class DesafioExtra : Form
    {
        public DesafioExtra()
        {
            InitializeComponent();
        }

        private void radioButtonPessoaFisica_CheckedChanged(object sender, EventArgs e)
        {
            bool pessoaFisica = radioButtonPessoaFisica.Checked;
            bool pessoaJuridica = radioButtonPessoaJuridica.Checked;

            if (radioButtonPessoaFisica.Checked)
            {
                labelNome.Text = "Nome";
                labelDocumento.Text = "CPF";
                labelValor.Text = "Salário";
            }
        }

        private void radioButtonPessoaJuridica_CheckedChanged(object sender, EventArgs e)
        {
            bool pessoaFisica = radioButtonPessoaFisica.Checked;
            bool pessoaJuridica = radioButtonPessoaJuridica.Checked;

            if (radioButtonPessoaJuridica.Checked)
            {
                labelNome.Text = "Razão Social";
                labelDocumento.Text = "CNPJ";
                labelValor.Text = "Faturamento";
            }
        }

        private void comboBoxParcelamento_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void buttonSimular_Click(object sender, EventArgs e)
        {
           



        }

      
    }
}
