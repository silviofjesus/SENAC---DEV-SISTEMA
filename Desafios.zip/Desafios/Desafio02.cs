﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desafios
{
    
    
    



    public partial class Desafio02 : Form
    {
        public double Depositar { get; set; }

        public double Sacar { get; set; }

        public double Saldo { get; set; }
            
        

        public Desafio02()
        {
            InitializeComponent();
        }

        private void buttonDepositar_Click(object sender, EventArgs e)
        {
            Depositar = Convert.ToDouble(textBoxDepositar.Text);
            Saldo = Depositar + Saldo;
            labelValoratual.Text = "" + Saldo;
            textBoxDepositar.Text = "";


        }

        private void buttonSacar_Click(object sender, EventArgs e)
        {
            Sacar = Convert.ToDouble(textBoxSacar.Text);
            Saldo = Saldo - Sacar;

            if (Sacar > Saldo)
            {
                MessageBox.Show("O saldo é insuficiente", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                textBoxSacar.Text = "";
            }
            else
            {
                labelValoratual.Text = "" + Saldo;
                textBoxSacar.Text = "";
            }

            
        }

        private void buttonEntrar_Click(object sender, EventArgs e)
        {
            //textBoxNumerodaConta.Text = buttonEntrar.Text;
            String Confirmar = textBoxNumerodaConta.Text;
            if (Confirmar == "1234")
            {
                MessageBox.Show("Acesso Liberado", "Login", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
                MessageBox.Show("Acesso Negado", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
