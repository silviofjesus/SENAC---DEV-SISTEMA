﻿namespace AdicionarElementos
{
    partial class SubstituirElementos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonAdicionar = new System.Windows.Forms.Button();
            this.textBoxAdicionar = new System.Windows.Forms.TextBox();
            this.buttonSubstituir = new System.Windows.Forms.Button();
            this.buttonExibir = new System.Windows.Forms.Button();
            this.textBoxSubstituir = new System.Windows.Forms.TextBox();
            this.buttonExibir2 = new System.Windows.Forms.Button();
            this.buttonSubstIndice = new System.Windows.Forms.Button();
            this.numericUpDownSubstIndice = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSubstIndice)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonAdicionar
            // 
            this.buttonAdicionar.Location = new System.Drawing.Point(32, 72);
            this.buttonAdicionar.Name = "buttonAdicionar";
            this.buttonAdicionar.Size = new System.Drawing.Size(87, 23);
            this.buttonAdicionar.TabIndex = 0;
            this.buttonAdicionar.Text = "Adicionar";
            this.buttonAdicionar.UseVisualStyleBackColor = true;
            this.buttonAdicionar.Click += new System.EventHandler(this.buttonAdicionar_Click);
            // 
            // textBoxAdicionar
            // 
            this.textBoxAdicionar.Location = new System.Drawing.Point(125, 73);
            this.textBoxAdicionar.Name = "textBoxAdicionar";
            this.textBoxAdicionar.Size = new System.Drawing.Size(169, 23);
            this.textBoxAdicionar.TabIndex = 1;
            // 
            // buttonSubstituir
            // 
            this.buttonSubstituir.Location = new System.Drawing.Point(32, 162);
            this.buttonSubstituir.Name = "buttonSubstituir";
            this.buttonSubstituir.Size = new System.Drawing.Size(87, 23);
            this.buttonSubstituir.TabIndex = 2;
            this.buttonSubstituir.Text = "Substituir";
            this.buttonSubstituir.UseVisualStyleBackColor = true;
            this.buttonSubstituir.Click += new System.EventHandler(this.buttonSubstituir_Click);
            // 
            // buttonExibir
            // 
            this.buttonExibir.Location = new System.Drawing.Point(300, 72);
            this.buttonExibir.Name = "buttonExibir";
            this.buttonExibir.Size = new System.Drawing.Size(75, 23);
            this.buttonExibir.TabIndex = 3;
            this.buttonExibir.Text = "Exibir";
            this.buttonExibir.UseVisualStyleBackColor = true;
            this.buttonExibir.Click += new System.EventHandler(this.buttonExibir_Click);
            // 
            // textBoxSubstituir
            // 
            this.textBoxSubstituir.Location = new System.Drawing.Point(125, 163);
            this.textBoxSubstituir.Name = "textBoxSubstituir";
            this.textBoxSubstituir.Size = new System.Drawing.Size(169, 23);
            this.textBoxSubstituir.TabIndex = 6;
            // 
            // buttonExibir2
            // 
            this.buttonExibir2.Location = new System.Drawing.Point(300, 163);
            this.buttonExibir2.Name = "buttonExibir2";
            this.buttonExibir2.Size = new System.Drawing.Size(75, 23);
            this.buttonExibir2.TabIndex = 7;
            this.buttonExibir2.Text = "Exibir2";
            this.buttonExibir2.UseVisualStyleBackColor = true;
            this.buttonExibir2.Click += new System.EventHandler(this.buttonExibir2_Click);
            // 
            // buttonSubstIndice
            // 
            this.buttonSubstIndice.Location = new System.Drawing.Point(35, 199);
            this.buttonSubstIndice.Name = "buttonSubstIndice";
            this.buttonSubstIndice.Size = new System.Drawing.Size(84, 23);
            this.buttonSubstIndice.TabIndex = 8;
            this.buttonSubstIndice.Text = "Subst Indice";
            this.buttonSubstIndice.UseVisualStyleBackColor = true;
            // 
            // numericUpDownSubstIndice
            // 
            this.numericUpDownSubstIndice.Location = new System.Drawing.Point(127, 200);
            this.numericUpDownSubstIndice.Name = "numericUpDownSubstIndice";
            this.numericUpDownSubstIndice.Size = new System.Drawing.Size(167, 23);
            this.numericUpDownSubstIndice.TabIndex = 9;
            // 
            // SubstituirElementos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.numericUpDownSubstIndice);
            this.Controls.Add(this.buttonSubstIndice);
            this.Controls.Add(this.buttonExibir2);
            this.Controls.Add(this.textBoxSubstituir);
            this.Controls.Add(this.buttonExibir);
            this.Controls.Add(this.buttonSubstituir);
            this.Controls.Add(this.textBoxAdicionar);
            this.Controls.Add(this.buttonAdicionar);
            this.Name = "SubstituirElementos";
            this.Text = "SubstituirElementos";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSubstIndice)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button buttonAdicionar;
        private TextBox textBoxAdicionar;
        private Button buttonSubstituir;
        private Button buttonExibir;
        private TextBox textBoxSubstituir;
        private Button buttonExibir2;
        private Button buttonSubstIndice;
        private NumericUpDown numericUpDownSubstIndice;
    }
}