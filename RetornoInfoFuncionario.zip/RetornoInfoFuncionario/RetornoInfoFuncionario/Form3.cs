﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RetornoInfoFuncionario.Classe;
using RetornoInfoFuncionario;

namespace RetornoInfoFuncionario
{
    public partial class Form3 : Form
    {
        public string NomeDaEmpresa { get; set; }

        public Form3()
        {
            InitializeComponent();
        }

        private void buttonCadastrarEmpresa_Click(object sender, EventArgs e)
        {
            NomeDaEmpresa = comboBoxEmpresa.Text;
            this.Close();

       

            

        }
    }
}
