﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desafios
{
    public partial class Desafio01 : Form
    {

           public Desafio01()
        {
            InitializeComponent();
        }

        private void textBoxNumero1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void buttonCalcular_Click(object sender, EventArgs e)
        {
           double numero1 = Convert.ToDouble(textBoxNumero1.Text);
           double numero2 = Convert.ToDouble(textBoxNumero2.Text);

            //verificar se esta marcado.
            bool Soma = radioButtonSomar.Checked;
            bool Subtrair = radioButtonSubtrair.Checked;
            bool Multiplicar = radioButtonMultiplicar.Checked;
            bool Dividir = radioButtonDividir.Checked;

            if (radioButtonSomar.Checked)
            {
                double Soma1 = numero1 + numero2;
                textBoxResultado.Text = "" + Soma1;

            }else if (radioButtonSubtrair.Checked) 
            { 
                double Subtrair1 = numero1 - numero2;
                textBoxResultado.Text = "" + Subtrair1;

            }
            if (radioButtonMultiplicar.Checked)
            {
                double Multiplicar1 = numero1 * numero2;
                textBoxResultado.Text = "" + Multiplicar1;
            }
            else if (radioButtonDividir.Checked)
            {
                if (numero2 == 0)
                {
                    MessageBox.Show("Zero(0) não é um numero válido");
                }
                else
                {
                    double dividir1 = numero1 / numero2;
                    textBoxResultado.Text = "" + dividir1;
                }
            }







        }
    }
}
