﻿namespace Desafios
{
    partial class Desafio01
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelNumero1 = new System.Windows.Forms.Label();
            this.labelNumero2 = new System.Windows.Forms.Label();
            this.textBoxNumero1 = new System.Windows.Forms.TextBox();
            this.textBoxNumero2 = new System.Windows.Forms.TextBox();
            this.radioButtonSomar = new System.Windows.Forms.RadioButton();
            this.radioButtonSubtrair = new System.Windows.Forms.RadioButton();
            this.radioButtonMultiplicar = new System.Windows.Forms.RadioButton();
            this.radioButtonDividir = new System.Windows.Forms.RadioButton();
            this.buttonCalcular = new System.Windows.Forms.Button();
            this.labelResultado = new System.Windows.Forms.Label();
            this.textBoxResultado = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // labelNumero1
            // 
            this.labelNumero1.AutoSize = true;
            this.labelNumero1.Location = new System.Drawing.Point(27, 67);
            this.labelNumero1.Name = "labelNumero1";
            this.labelNumero1.Size = new System.Drawing.Size(60, 15);
            this.labelNumero1.TabIndex = 0;
            this.labelNumero1.Text = "Numero 1";
            // 
            // labelNumero2
            // 
            this.labelNumero2.AutoSize = true;
            this.labelNumero2.Location = new System.Drawing.Point(190, 67);
            this.labelNumero2.Name = "labelNumero2";
            this.labelNumero2.Size = new System.Drawing.Size(60, 15);
            this.labelNumero2.TabIndex = 1;
            this.labelNumero2.Text = "Numero 2";
            // 
            // textBoxNumero1
            // 
            this.textBoxNumero1.Location = new System.Drawing.Point(27, 85);
            this.textBoxNumero1.Name = "textBoxNumero1";
            this.textBoxNumero1.Size = new System.Drawing.Size(100, 23);
            this.textBoxNumero1.TabIndex = 2;
            this.textBoxNumero1.TextChanged += new System.EventHandler(this.textBoxNumero1_TextChanged);
            // 
            // textBoxNumero2
            // 
            this.textBoxNumero2.Location = new System.Drawing.Point(190, 85);
            this.textBoxNumero2.Name = "textBoxNumero2";
            this.textBoxNumero2.Size = new System.Drawing.Size(100, 23);
            this.textBoxNumero2.TabIndex = 3;
            // 
            // radioButtonSomar
            // 
            this.radioButtonSomar.AutoSize = true;
            this.radioButtonSomar.Location = new System.Drawing.Point(27, 174);
            this.radioButtonSomar.Name = "radioButtonSomar";
            this.radioButtonSomar.Size = new System.Drawing.Size(59, 19);
            this.radioButtonSomar.TabIndex = 4;
            this.radioButtonSomar.TabStop = true;
            this.radioButtonSomar.Text = "Somar";
            this.radioButtonSomar.UseVisualStyleBackColor = true;
            // 
            // radioButtonSubtrair
            // 
            this.radioButtonSubtrair.AutoSize = true;
            this.radioButtonSubtrair.Location = new System.Drawing.Point(27, 217);
            this.radioButtonSubtrair.Name = "radioButtonSubtrair";
            this.radioButtonSubtrair.Size = new System.Drawing.Size(66, 19);
            this.radioButtonSubtrair.TabIndex = 5;
            this.radioButtonSubtrair.TabStop = true;
            this.radioButtonSubtrair.Text = "Subtrair";
            this.radioButtonSubtrair.UseVisualStyleBackColor = true;
            // 
            // radioButtonMultiplicar
            // 
            this.radioButtonMultiplicar.AutoSize = true;
            this.radioButtonMultiplicar.Location = new System.Drawing.Point(27, 256);
            this.radioButtonMultiplicar.Name = "radioButtonMultiplicar";
            this.radioButtonMultiplicar.Size = new System.Drawing.Size(82, 19);
            this.radioButtonMultiplicar.TabIndex = 6;
            this.radioButtonMultiplicar.TabStop = true;
            this.radioButtonMultiplicar.Text = "Multiplicar";
            this.radioButtonMultiplicar.UseVisualStyleBackColor = true;
            // 
            // radioButtonDividir
            // 
            this.radioButtonDividir.AutoSize = true;
            this.radioButtonDividir.Location = new System.Drawing.Point(27, 302);
            this.radioButtonDividir.Name = "radioButtonDividir";
            this.radioButtonDividir.Size = new System.Drawing.Size(59, 19);
            this.radioButtonDividir.TabIndex = 7;
            this.radioButtonDividir.TabStop = true;
            this.radioButtonDividir.Text = "Dividir";
            this.radioButtonDividir.UseVisualStyleBackColor = true;
            // 
            // buttonCalcular
            // 
            this.buttonCalcular.Location = new System.Drawing.Point(190, 252);
            this.buttonCalcular.Name = "buttonCalcular";
            this.buttonCalcular.Size = new System.Drawing.Size(100, 23);
            this.buttonCalcular.TabIndex = 8;
            this.buttonCalcular.Text = "Calcular";
            this.buttonCalcular.UseVisualStyleBackColor = true;
            this.buttonCalcular.Click += new System.EventHandler(this.buttonCalcular_Click);
            // 
            // labelResultado
            // 
            this.labelResultado.AutoSize = true;
            this.labelResultado.Location = new System.Drawing.Point(27, 399);
            this.labelResultado.Name = "labelResultado";
            this.labelResultado.Size = new System.Drawing.Size(59, 15);
            this.labelResultado.TabIndex = 9;
            this.labelResultado.Text = "Resultado";
            // 
            // textBoxResultado
            // 
            this.textBoxResultado.Location = new System.Drawing.Point(27, 417);
            this.textBoxResultado.Name = "textBoxResultado";
            this.textBoxResultado.Size = new System.Drawing.Size(263, 23);
            this.textBoxResultado.TabIndex = 10;
            // 
            // Desafio01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(337, 496);
            this.Controls.Add(this.textBoxResultado);
            this.Controls.Add(this.labelResultado);
            this.Controls.Add(this.buttonCalcular);
            this.Controls.Add(this.radioButtonDividir);
            this.Controls.Add(this.radioButtonMultiplicar);
            this.Controls.Add(this.radioButtonSubtrair);
            this.Controls.Add(this.radioButtonSomar);
            this.Controls.Add(this.textBoxNumero2);
            this.Controls.Add(this.textBoxNumero1);
            this.Controls.Add(this.labelNumero2);
            this.Controls.Add(this.labelNumero1);
            this.Name = "Desafio01";
            this.Text = "Desafio01";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label labelNumero1;
        private Label labelNumero2;
        private TextBox textBoxNumero1;
        private TextBox textBoxNumero2;
        private RadioButton radioButtonSomar;
        private RadioButton radioButtonSubtrair;
        private RadioButton radioButtonMultiplicar;
        private RadioButton radioButtonDividir;
        private Button buttonCalcular;
        private Label labelResultado;
        private TextBox textBoxResultado;
    }
}