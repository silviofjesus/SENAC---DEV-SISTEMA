﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdicionarElementos
{
    public partial class ElementosMinimoMaximo : Form
    {

        List<int> numeros = new List<int>();

        public ElementosMinimoMaximo()
        {
            InitializeComponent();
        }

        private void buttonAdicionar_Click(object sender, EventArgs e)
        {
            int adicionar = Convert.ToInt32(textBoxAdcionar.Text);

            numeros.Add(adicionar);

            textBoxAdcionar.Text = "";
        }

        private void buttonMenorNumero_Click(object sender, EventArgs e)
        {
            int menorNumero = numeros.Min();

            MessageBox.Show(Convert.ToString(menorNumero));
        }

        private void buttonMaiorNumero_Click(object sender, EventArgs e)
        {
            int maiorNumero = numeros.Max();

            MessageBox.Show(Convert.ToString(maiorNumero));
        }
    }
}
