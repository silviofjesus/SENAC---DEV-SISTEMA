﻿namespace AdicionarElementos
{
    partial class ElementosMinimoMaximo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonAdicionar = new System.Windows.Forms.Button();
            this.textBoxAdcionar = new System.Windows.Forms.TextBox();
            this.buttonMenorNumero = new System.Windows.Forms.Button();
            this.buttonMaiorNumero = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonAdicionar
            // 
            this.buttonAdicionar.Location = new System.Drawing.Point(34, 58);
            this.buttonAdicionar.Name = "buttonAdicionar";
            this.buttonAdicionar.Size = new System.Drawing.Size(75, 23);
            this.buttonAdicionar.TabIndex = 0;
            this.buttonAdicionar.Text = "adicionar";
            this.buttonAdicionar.UseVisualStyleBackColor = true;
            this.buttonAdicionar.Click += new System.EventHandler(this.buttonAdicionar_Click);
            // 
            // textBoxAdcionar
            // 
            this.textBoxAdcionar.Location = new System.Drawing.Point(115, 59);
            this.textBoxAdcionar.Name = "textBoxAdcionar";
            this.textBoxAdcionar.Size = new System.Drawing.Size(100, 23);
            this.textBoxAdcionar.TabIndex = 1;
            // 
            // buttonMenorNumero
            // 
            this.buttonMenorNumero.Location = new System.Drawing.Point(34, 102);
            this.buttonMenorNumero.Name = "buttonMenorNumero";
            this.buttonMenorNumero.Size = new System.Drawing.Size(75, 52);
            this.buttonMenorNumero.TabIndex = 2;
            this.buttonMenorNumero.Text = "Menor Numero";
            this.buttonMenorNumero.UseVisualStyleBackColor = true;
            this.buttonMenorNumero.Click += new System.EventHandler(this.buttonMenorNumero_Click);
            // 
            // buttonMaiorNumero
            // 
            this.buttonMaiorNumero.Location = new System.Drawing.Point(34, 176);
            this.buttonMaiorNumero.Name = "buttonMaiorNumero";
            this.buttonMaiorNumero.Size = new System.Drawing.Size(75, 58);
            this.buttonMaiorNumero.TabIndex = 3;
            this.buttonMaiorNumero.Text = "Maior Numero";
            this.buttonMaiorNumero.UseVisualStyleBackColor = true;
            this.buttonMaiorNumero.Click += new System.EventHandler(this.buttonMaiorNumero_Click);
            // 
            // ElementosMinimoMaximo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonMaiorNumero);
            this.Controls.Add(this.buttonMenorNumero);
            this.Controls.Add(this.textBoxAdcionar);
            this.Controls.Add(this.buttonAdicionar);
            this.Name = "ElementosMinimoMaximo";
            this.Text = "ElementosMinimoMaximo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button buttonAdicionar;
        private TextBox textBoxAdcionar;
        private Button buttonMenorNumero;
        private Button buttonMaiorNumero;
    }
}