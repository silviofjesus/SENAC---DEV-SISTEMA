﻿using System;
using Exercicio02.Classes;
using Exercicio02.Classes02;



class Program
{
   static void Main()
    {
        //exercicio 01
        Ponto p = new Ponto(10, 5);
        Console.WriteLine("Exercicio 01");
        Console.WriteLine("Coordenada X = " + p.X);
        Console.WriteLine("Coordenada Y = " + p.Y);
        Console.WriteLine();

        //exercicio 02
        Console.WriteLine("Exercicio 02");
        Retangulo Operacao = new Retangulo(10, 20);
        Console.WriteLine(Operacao.Largura * Operacao.Comprimento);
        Console.WriteLine();

        //exercicio 03
        Console.WriteLine("Exercicio 03");
        Pessoa pessoa = new Pessoa("Silvio", 41);
        //pessoa.apresentar();
        pessoa.detalhes();
        Console.WriteLine();

        //exercicio 04
        Console.WriteLine("Exercicio 04");
        Calc calc = new Calc(10, 5);
        calc.adicao();
        calc.subt();
        calc.mult();
        calc.div();
        Console.WriteLine();

        //exercicio 05
        Console.WriteLine("Exercicio 05");
        Triangulo triangulo = new Triangulo(10, 20, 30);
        Console.WriteLine();

        //exercicio 06
        Contador contador = new Contador(10);
        contador.ContadorFor();
        Console.WriteLine();

        Contador contador2 = new Contador(-10);
        contador2.ContadorWhile();

        //exercicio 07

        ContaBancaria contabancaria = new ContaBancaria(1234, 1000);
        contabancaria.Depositar(100);
        contabancaria.Sacar(500);

        

        

















    }
}