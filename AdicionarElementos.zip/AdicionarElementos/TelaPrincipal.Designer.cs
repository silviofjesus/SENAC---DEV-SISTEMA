﻿namespace AdicionarElementos
{
    partial class TelaPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonAdicionarElementos = new System.Windows.Forms.Button();
            this.buttonRemoverElementos = new System.Windows.Forms.Button();
            this.buttonOrdenarLista = new System.Windows.Forms.Button();
            this.buttonFiltrarElementos = new System.Windows.Forms.Button();
            this.buttonInverterLista = new System.Windows.Forms.Button();
            this.buttonContarElementos = new System.Windows.Forms.Button();
            this.buttonSomarElementos = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.buttonSubstituirElementos = new System.Windows.Forms.Button();
            this.buttonMesclarListas = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonAdicionarElementos
            // 
            this.buttonAdicionarElementos.Location = new System.Drawing.Point(35, 53);
            this.buttonAdicionarElementos.Name = "buttonAdicionarElementos";
            this.buttonAdicionarElementos.Size = new System.Drawing.Size(147, 23);
            this.buttonAdicionarElementos.TabIndex = 0;
            this.buttonAdicionarElementos.Text = "Adicionar Elementos";
            this.buttonAdicionarElementos.UseVisualStyleBackColor = true;
            // 
            // buttonRemoverElementos
            // 
            this.buttonRemoverElementos.Location = new System.Drawing.Point(35, 95);
            this.buttonRemoverElementos.Name = "buttonRemoverElementos";
            this.buttonRemoverElementos.Size = new System.Drawing.Size(147, 23);
            this.buttonRemoverElementos.TabIndex = 1;
            this.buttonRemoverElementos.Text = "Remover Elementos";
            this.buttonRemoverElementos.UseVisualStyleBackColor = true;
            // 
            // buttonOrdenarLista
            // 
            this.buttonOrdenarLista.Location = new System.Drawing.Point(35, 140);
            this.buttonOrdenarLista.Name = "buttonOrdenarLista";
            this.buttonOrdenarLista.Size = new System.Drawing.Size(147, 23);
            this.buttonOrdenarLista.TabIndex = 2;
            this.buttonOrdenarLista.Text = "Ordenar Lista";
            this.buttonOrdenarLista.UseVisualStyleBackColor = true;
            // 
            // buttonFiltrarElementos
            // 
            this.buttonFiltrarElementos.Location = new System.Drawing.Point(35, 185);
            this.buttonFiltrarElementos.Name = "buttonFiltrarElementos";
            this.buttonFiltrarElementos.Size = new System.Drawing.Size(147, 23);
            this.buttonFiltrarElementos.TabIndex = 3;
            this.buttonFiltrarElementos.Text = "Filtrar Elementos";
            this.buttonFiltrarElementos.UseVisualStyleBackColor = true;
            // 
            // buttonInverterLista
            // 
            this.buttonInverterLista.Location = new System.Drawing.Point(35, 228);
            this.buttonInverterLista.Name = "buttonInverterLista";
            this.buttonInverterLista.Size = new System.Drawing.Size(147, 23);
            this.buttonInverterLista.TabIndex = 4;
            this.buttonInverterLista.Text = "Inverter Lista";
            this.buttonInverterLista.UseVisualStyleBackColor = true;
            // 
            // buttonContarElementos
            // 
            this.buttonContarElementos.Location = new System.Drawing.Point(35, 270);
            this.buttonContarElementos.Name = "buttonContarElementos";
            this.buttonContarElementos.Size = new System.Drawing.Size(147, 23);
            this.buttonContarElementos.TabIndex = 5;
            this.buttonContarElementos.Text = "Contar Elementos";
            this.buttonContarElementos.UseVisualStyleBackColor = true;
            this.buttonContarElementos.Click += new System.EventHandler(this.buttonContarElementos_Click);
            // 
            // buttonSomarElementos
            // 
            this.buttonSomarElementos.Location = new System.Drawing.Point(35, 314);
            this.buttonSomarElementos.Name = "buttonSomarElementos";
            this.buttonSomarElementos.Size = new System.Drawing.Size(147, 23);
            this.buttonSomarElementos.TabIndex = 6;
            this.buttonSomarElementos.Text = "Somar Elementos";
            this.buttonSomarElementos.UseVisualStyleBackColor = true;
            this.buttonSomarElementos.Click += new System.EventHandler(this.buttonSomarElementos_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(35, 358);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(147, 51);
            this.button1.TabIndex = 7;
            this.button1.Text = "Elementos Minimo e Maximo";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonSubstituirElementos
            // 
            this.buttonSubstituirElementos.Location = new System.Drawing.Point(35, 424);
            this.buttonSubstituirElementos.Name = "buttonSubstituirElementos";
            this.buttonSubstituirElementos.Size = new System.Drawing.Size(147, 23);
            this.buttonSubstituirElementos.TabIndex = 8;
            this.buttonSubstituirElementos.Text = "Substituir Elementos";
            this.buttonSubstituirElementos.UseVisualStyleBackColor = true;
            this.buttonSubstituirElementos.Click += new System.EventHandler(this.buttonSubstituirElementos_Click);
            // 
            // buttonMesclarListas
            // 
            this.buttonMesclarListas.Location = new System.Drawing.Point(38, 470);
            this.buttonMesclarListas.Name = "buttonMesclarListas";
            this.buttonMesclarListas.Size = new System.Drawing.Size(144, 23);
            this.buttonMesclarListas.TabIndex = 9;
            this.buttonMesclarListas.Text = "Mesclar Listas";
            this.buttonMesclarListas.UseVisualStyleBackColor = true;
            this.buttonMesclarListas.Click += new System.EventHandler(this.buttonMesclarListas_Click);
            // 
            // TelaPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 582);
            this.Controls.Add(this.buttonMesclarListas);
            this.Controls.Add(this.buttonSubstituirElementos);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.buttonSomarElementos);
            this.Controls.Add(this.buttonContarElementos);
            this.Controls.Add(this.buttonInverterLista);
            this.Controls.Add(this.buttonFiltrarElementos);
            this.Controls.Add(this.buttonOrdenarLista);
            this.Controls.Add(this.buttonRemoverElementos);
            this.Controls.Add(this.buttonAdicionarElementos);
            this.Name = "TelaPrincipal";
            this.Text = "TelaPrincipal";
            this.ResumeLayout(false);

        }

        #endregion

        private Button buttonAdicionarElementos;
        private Button buttonRemoverElementos;
        private Button buttonOrdenarLista;
        private Button buttonFiltrarElementos;
        private Button buttonInverterLista;
        private Button buttonContarElementos;
        private Button buttonSomarElementos;
        private Button button1;
        private Button buttonSubstituirElementos;
        private Button buttonMesclarListas;
    }
}