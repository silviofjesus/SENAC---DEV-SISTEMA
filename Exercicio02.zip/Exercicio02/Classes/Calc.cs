﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio02.Classes
{
    public class Calc
    {
        public double Numero1 { get; set;}
        public double Numero2 { get; set;}

        public Calc(double numero1, double numero2)
        {
            this.Numero1 = numero1;
            this.Numero2 = numero2;
        }

        public void adicao()
        {
            double soma = Numero1 + Numero2;
            Console.WriteLine("Adição: " + soma);
        }

        public void subt()
        {
            double sub = Numero1 - Numero2;
            Console.WriteLine("Subtração: " + sub);
        }

        public void mult()
        {
            double mult = Numero1 * Numero2;
            Console.WriteLine("Multiplicação: " + mult);
        }
        public void div()
        {
            if (ValidarDivisao (Numero2) == true)
            {
                double div = Numero1 / Numero2;
                Console.WriteLine("Divisão: " + div);
            }
            else
            {
                Console.WriteLine("Divisão não pode ser por ZERO");
                
            }
           
        }

        private bool ValidarDivisao(double valor)
        {
            if (valor == 0)
            {
                return false;
            }
            else
            {
                return true;
            }

        }

    }
}
