﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdicionarElementos
{
    public partial class InverterLista : Form
    {
        List<string> lista = new List<string>();

        public InverterLista()
        {
            InitializeComponent();
        }

        private void buttonAdicionar_Click(object sender, EventArgs e)
        {
            int adicionar = Convert.ToInt32(textBoxAdicionar.Text);

            lista.Add(Convert.ToString(adicionar));

            textBoxAdicionar.Text = "";


        }

        private void buttonExibir_Click(object sender, EventArgs e)
        {
            string exibir = "";

            foreach (var item in lista)
            {
                exibir += item + "\n";
            }

            MessageBox.Show(exibir);
        }

        private void buttonInverter_Click(object sender, EventArgs e)
        {
            string inverter = "";

            //lista.Sort();
            lista.Reverse();

            foreach (var item in lista)
            {
                inverter += item + "\n";
            }

            MessageBox.Show(inverter);
        }

      
    }
}
