namespace AdicionarElementos
{
    public partial class AdicionarElementos : Form
    {
        List<int> numeros = new List<int>();

        public AdicionarElementos()
        {
            InitializeComponent();
        }

        private void buttonAdicionar_Click(object sender, EventArgs e)
        {
            int num = Convert.ToInt32(textBoxAdicionar.Text);
            numeros.Add(num);
            textBoxAdicionar.Text = "";


        }

        private void buttonExibir_Click(object sender, EventArgs e)
        {
            String numeroExibir = "";

            foreach (var item in numeros)
            {
                numeroExibir += item + "\n";
            }

            MessageBox.Show(numeroExibir);
        }
    }
}