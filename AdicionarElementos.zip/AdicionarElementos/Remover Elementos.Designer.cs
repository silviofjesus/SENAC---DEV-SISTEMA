﻿namespace AdicionarElementos
{
    partial class Remover_Elementos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonExibir = new Button();
            buttonRemover = new Button();
            textBoxremover = new TextBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // buttonExibir
            // 
            buttonExibir.Location = new Point(68, 70);
            buttonExibir.Name = "buttonExibir";
            buttonExibir.Size = new Size(75, 23);
            buttonExibir.TabIndex = 0;
            buttonExibir.Text = "Exibir ";
            buttonExibir.UseVisualStyleBackColor = true;
            buttonExibir.Click += buttonExibir_Click;
            // 
            // buttonRemover
            // 
            buttonRemover.Location = new Point(68, 110);
            buttonRemover.Name = "buttonRemover";
            buttonRemover.Size = new Size(75, 23);
            buttonRemover.TabIndex = 1;
            buttonRemover.Text = "Remover";
            buttonRemover.UseVisualStyleBackColor = true;
            buttonRemover.Click += buttonRemover_Click;
            // 
            // textBoxremover
            // 
            textBoxremover.Location = new Point(149, 111);
            textBoxremover.Name = "textBoxremover";
            textBoxremover.Size = new Size(100, 23);
            textBoxremover.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(68, 36);
            label1.Name = "label1";
            label1.Size = new Size(112, 15);
            label1.TabIndex = 3;
            label1.Text = "Remover Elementos";
            // 
            // Remover_Elementos
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(385, 251);
            Controls.Add(label1);
            Controls.Add(textBoxremover);
            Controls.Add(buttonRemover);
            Controls.Add(buttonExibir);
            Name = "Remover_Elementos";
            Text = "Remover_Elementos";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonExibir;
        private Button buttonRemover;
        private TextBox textBoxremover;
        private Label label1;
    }
}