﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using IMC.Classe;

namespace IMC
{
    public partial class Form2 : Form
    {
        Pessoa pessoa = new Pessoa();
        
        public Form2(Pessoa P)
        {
            InitializeComponent();

            pessoa = P;
        }

        private void Form2_Load(object sender, EventArgs e)
        {

            double IMC;

           IMC = pessoa.Peso / (pessoa.Altura * pessoa.Altura);

            labelResultadoIMC.Text = IMC.ToString();
            
            
        }
    }
}
