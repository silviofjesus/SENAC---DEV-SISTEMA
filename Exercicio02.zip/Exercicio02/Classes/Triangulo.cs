﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio02.Classes
{
    public class Triangulo
    {
        public double LadoA { get; set;}
        public double LadoB { get; set;}
        public double LadoC { get; set;}

        public Triangulo(double ladoA, double ladoB, double ladoC)
        {
            LadoA = ladoA;
            LadoB = ladoB;
            LadoC = ladoC;
            VerificarTringulo();

        }

        public void VerificarTringulo()
        {
            if (LadoA == LadoB && LadoB == LadoC)
            {
                Console.WriteLine("Equilátero");
            }
            else
            {
                if (LadoA != LadoB && LadoB != LadoC && LadoC != LadoA)
                {
                    Console.WriteLine("Escaleno");
                }
                else
                {
                    Console.WriteLine("Isóceles");
                }
            }
        }


    }
}
