﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio02.Classes
{
    public class Contador
    {
        private int Numero { get; set; }

       public Contador(int num)
        {
            this.Numero = num;
        }

        public void ContadorFor()
        {
            for (int i = 1; i < 10; i++)
            {
                Console.WriteLine(i);
            }
            
        }

        public void ContadorWhile()
        {
            while (Numero <= 10)
            {
                Console.WriteLine(Numero);
                Numero++;
            }
            
        }
    }
}
