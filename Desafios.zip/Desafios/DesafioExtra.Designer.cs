﻿namespace Desafios
{
    partial class DesafioExtra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelTipodePessoa = new System.Windows.Forms.Label();
            this.radioButtonPessoaFisica = new System.Windows.Forms.RadioButton();
            this.radioButtonPessoaJuridica = new System.Windows.Forms.RadioButton();
            this.labelNome = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.labelDocumento = new System.Windows.Forms.Label();
            this.textBoxDocumento = new System.Windows.Forms.TextBox();
            this.labelValor = new System.Windows.Forms.Label();
            this.numericUpDownValor = new System.Windows.Forms.NumericUpDown();
            this.labelValordoEmprestimo = new System.Windows.Forms.Label();
            this.numericUpDownValordoEmprestimo = new System.Windows.Forms.NumericUpDown();
            this.comboBoxParcelamento = new System.Windows.Forms.ComboBox();
            this.labelParcelamento = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.buttonSimular = new System.Windows.Forms.Button();
            this.labelResultadoSimulacao = new System.Windows.Forms.Label();
            this.textBoxresultadodasimulacao = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownValor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownValordoEmprestimo)).BeginInit();
            this.SuspendLayout();
            // 
            // labelTipodePessoa
            // 
            this.labelTipodePessoa.AutoSize = true;
            this.labelTipodePessoa.Location = new System.Drawing.Point(26, 28);
            this.labelTipodePessoa.Name = "labelTipodePessoa";
            this.labelTipodePessoa.Size = new System.Drawing.Size(88, 15);
            this.labelTipodePessoa.TabIndex = 0;
            this.labelTipodePessoa.Text = "Tipo de Pessoa:";
            // 
            // radioButtonPessoaFisica
            // 
            this.radioButtonPessoaFisica.AutoSize = true;
            this.radioButtonPessoaFisica.Location = new System.Drawing.Point(26, 56);
            this.radioButtonPessoaFisica.Name = "radioButtonPessoaFisica";
            this.radioButtonPessoaFisica.Size = new System.Drawing.Size(93, 19);
            this.radioButtonPessoaFisica.TabIndex = 1;
            this.radioButtonPessoaFisica.TabStop = true;
            this.radioButtonPessoaFisica.Text = "Pessoa Fisica";
            this.radioButtonPessoaFisica.UseVisualStyleBackColor = true;
            this.radioButtonPessoaFisica.CheckedChanged += new System.EventHandler(this.radioButtonPessoaFisica_CheckedChanged);
            // 
            // radioButtonPessoaJuridica
            // 
            this.radioButtonPessoaJuridica.AutoSize = true;
            this.radioButtonPessoaJuridica.Location = new System.Drawing.Point(26, 81);
            this.radioButtonPessoaJuridica.Name = "radioButtonPessoaJuridica";
            this.radioButtonPessoaJuridica.Size = new System.Drawing.Size(104, 19);
            this.radioButtonPessoaJuridica.TabIndex = 2;
            this.radioButtonPessoaJuridica.TabStop = true;
            this.radioButtonPessoaJuridica.Text = "Pessoa Juridica";
            this.radioButtonPessoaJuridica.UseVisualStyleBackColor = true;
            this.radioButtonPessoaJuridica.CheckedChanged += new System.EventHandler(this.radioButtonPessoaJuridica_CheckedChanged);
            // 
            // labelNome
            // 
            this.labelNome.AutoSize = true;
            this.labelNome.Location = new System.Drawing.Point(26, 129);
            this.labelNome.Name = "labelNome";
            this.labelNome.Size = new System.Drawing.Size(40, 15);
            this.labelNome.TabIndex = 3;
            this.labelNome.Text = "Nome";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(26, 147);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(397, 23);
            this.textBox1.TabIndex = 4;
            // 
            // labelDocumento
            // 
            this.labelDocumento.AutoSize = true;
            this.labelDocumento.Location = new System.Drawing.Point(444, 129);
            this.labelDocumento.Name = "labelDocumento";
            this.labelDocumento.Size = new System.Drawing.Size(70, 15);
            this.labelDocumento.TabIndex = 5;
            this.labelDocumento.Text = "Documento";
            // 
            // textBoxDocumento
            // 
            this.textBoxDocumento.Location = new System.Drawing.Point(444, 147);
            this.textBoxDocumento.Name = "textBoxDocumento";
            this.textBoxDocumento.Size = new System.Drawing.Size(217, 23);
            this.textBoxDocumento.TabIndex = 6;
            // 
            // labelValor
            // 
            this.labelValor.AutoSize = true;
            this.labelValor.Location = new System.Drawing.Point(26, 194);
            this.labelValor.Name = "labelValor";
            this.labelValor.Size = new System.Drawing.Size(33, 15);
            this.labelValor.TabIndex = 7;
            this.labelValor.Text = "Valor";
            // 
            // numericUpDownValor
            // 
            this.numericUpDownValor.Location = new System.Drawing.Point(26, 212);
            this.numericUpDownValor.Name = "numericUpDownValor";
            this.numericUpDownValor.Size = new System.Drawing.Size(635, 23);
            this.numericUpDownValor.TabIndex = 8;
            // 
            // labelValordoEmprestimo
            // 
            this.labelValordoEmprestimo.AutoSize = true;
            this.labelValordoEmprestimo.Location = new System.Drawing.Point(26, 261);
            this.labelValordoEmprestimo.Name = "labelValordoEmprestimo";
            this.labelValordoEmprestimo.Size = new System.Drawing.Size(117, 15);
            this.labelValordoEmprestimo.TabIndex = 9;
            this.labelValordoEmprestimo.Text = "Valor do Emprestimo";
            // 
            // numericUpDownValordoEmprestimo
            // 
            this.numericUpDownValordoEmprestimo.Location = new System.Drawing.Point(26, 279);
            this.numericUpDownValordoEmprestimo.Name = "numericUpDownValordoEmprestimo";
            this.numericUpDownValordoEmprestimo.Size = new System.Drawing.Size(243, 23);
            this.numericUpDownValordoEmprestimo.TabIndex = 10;
            // 
            // comboBoxParcelamento
            // 
            this.comboBoxParcelamento.FormattingEnabled = true;
            this.comboBoxParcelamento.Items.AddRange(new object[] {
            "12",
            "24",
            "36",
            "48"});
            this.comboBoxParcelamento.Location = new System.Drawing.Point(292, 279);
            this.comboBoxParcelamento.Name = "comboBoxParcelamento";
            this.comboBoxParcelamento.Size = new System.Drawing.Size(131, 23);
            this.comboBoxParcelamento.TabIndex = 11;
            this.comboBoxParcelamento.SelectedIndexChanged += new System.EventHandler(this.comboBoxParcelamento_SelectedIndexChanged);
            // 
            // labelParcelamento
            // 
            this.labelParcelamento.AutoSize = true;
            this.labelParcelamento.Location = new System.Drawing.Point(292, 261);
            this.labelParcelamento.Name = "labelParcelamento";
            this.labelParcelamento.Size = new System.Drawing.Size(80, 15);
            this.labelParcelamento.TabIndex = 12;
            this.labelParcelamento.Text = "Parcelamento";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(444, 283);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(166, 19);
            this.checkBox1.TabIndex = 13;
            this.checkBox1.Text = "Incluir Seguro Emprestimo";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // buttonSimular
            // 
            this.buttonSimular.Location = new System.Drawing.Point(26, 351);
            this.buttonSimular.Name = "buttonSimular";
            this.buttonSimular.Size = new System.Drawing.Size(75, 23);
            this.buttonSimular.TabIndex = 14;
            this.buttonSimular.Text = "Simular";
            this.buttonSimular.UseVisualStyleBackColor = true;
            this.buttonSimular.Click += new System.EventHandler(this.buttonSimular_Click);
            // 
            // labelResultadoSimulacao
            // 
            this.labelResultadoSimulacao.AutoSize = true;
            this.labelResultadoSimulacao.Location = new System.Drawing.Point(26, 410);
            this.labelResultadoSimulacao.Name = "labelResultadoSimulacao";
            this.labelResultadoSimulacao.Size = new System.Drawing.Size(133, 15);
            this.labelResultadoSimulacao.TabIndex = 15;
            this.labelResultadoSimulacao.Text = "Resultado da Simulação";
            // 
            // textBoxresultadodasimulacao
            // 
            this.textBoxresultadodasimulacao.Location = new System.Drawing.Point(31, 443);
            this.textBoxresultadodasimulacao.Multiline = true;
            this.textBoxresultadodasimulacao.Name = "textBoxresultadodasimulacao";
            this.textBoxresultadodasimulacao.Size = new System.Drawing.Size(630, 212);
            this.textBoxresultadodasimulacao.TabIndex = 16;
            // 
            // DesafioExtra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(693, 700);
            this.Controls.Add(this.textBoxresultadodasimulacao);
            this.Controls.Add(this.labelResultadoSimulacao);
            this.Controls.Add(this.buttonSimular);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.labelParcelamento);
            this.Controls.Add(this.comboBoxParcelamento);
            this.Controls.Add(this.numericUpDownValordoEmprestimo);
            this.Controls.Add(this.labelValordoEmprestimo);
            this.Controls.Add(this.numericUpDownValor);
            this.Controls.Add(this.labelValor);
            this.Controls.Add(this.textBoxDocumento);
            this.Controls.Add(this.labelDocumento);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.labelNome);
            this.Controls.Add(this.radioButtonPessoaJuridica);
            this.Controls.Add(this.radioButtonPessoaFisica);
            this.Controls.Add(this.labelTipodePessoa);
            this.Name = "DesafioExtra";
            this.Text = "DesafioExtra";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownValor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownValordoEmprestimo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label labelTipodePessoa;
        private RadioButton radioButtonPessoaFisica;
        private RadioButton radioButtonPessoaJuridica;
        private Label labelNome;
        private TextBox textBox1;
        private Label labelDocumento;
        private TextBox textBoxDocumento;
        private Label labelValor;
        private NumericUpDown numericUpDownValor;
        private Label labelValordoEmprestimo;
        private NumericUpDown numericUpDownValordoEmprestimo;
        private ComboBox comboBoxParcelamento;
        private Label labelParcelamento;
        private CheckBox checkBox1;
        private Button buttonSimular;
        private Label labelResultadoSimulacao;
        private TextBox textBoxresultadodasimulacao;
    }
}