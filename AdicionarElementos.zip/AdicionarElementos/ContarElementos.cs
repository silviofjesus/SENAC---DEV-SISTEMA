﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdicionarElementos
{
    public partial class ContarElementos : Form
    {
        List<int> numeros = new List<int>();

        public ContarElementos()
        {
            InitializeComponent();
        }

        private void buttonAdicionar_Click(object sender, EventArgs e)
        {
            string adicionar = textBoxAdicionar.Text;

            numeros.Add(Convert.ToInt32(adicionar));

            textBoxAdicionar.Text = "";

         }

        private void button2_Click(object sender, EventArgs e)

        {
           int contar = Convert.ToInt32(textBoxContarElementos.Text);

           // string exibir = "";

            contar = numeros.Count(x => x == contar);

            
          MessageBox.Show(Convert.ToString(contar));

        }

        private void buttonExibir_Click(object sender, EventArgs e)
        {
            string exibir = "";

            foreach (int i in numeros)
            {
                exibir += i + "\n";
            }
            MessageBox.Show(exibir);

        }
    }
}
