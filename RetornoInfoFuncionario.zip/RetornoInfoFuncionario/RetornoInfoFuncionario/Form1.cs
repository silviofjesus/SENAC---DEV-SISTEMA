using RetornoInfoFuncionario.Classe;
using RetornoInfoFuncionario;


namespace RetornoInfoFuncionario
{
    

    public partial class Form1 : Form
    {
        List<Funcionario> Listadefuncionario = new List<Funcionario>();

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCadastrarFuncionario_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.ShowDialog();

            Funcionario f = new Funcionario();

            f = form2.funcionario;

            Listadefuncionario.Add(f);



        }

        private void button1_Click(object sender, EventArgs e)
        {
            string exibir = "";

            foreach (Funcionario item in Listadefuncionario)
            {
                exibir += item.Nome + " - " + item.CPF + " - " + item.Empresa + "\n";
            }

            MessageBox.Show(exibir);
        }
    }
}