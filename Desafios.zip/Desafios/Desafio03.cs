﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Desafios
{
    public partial class Desafio03 : Form
    {
        public Desafio03()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nome = labelNome.Text;

            //bool marcado1 = checkBoxPizza.Checked;
            //bool marcado2 = checkBoxHamgurguer.Checked;
            //bool marcado3 = checkBoxJaponesa.Checked;
            //bool marcado4 = checkBoxMassas.Checked;
            //bool marcado5 = checkBoxSobremessas.Checked;
            //bool marcado6 = checkBoxChurrasco.Checked;

            string mostrar = "O Cliente escolheu: ";

            if (checkBoxPizza.Checked)
            {
                mostrar += checkBoxPizza.Text + ", ";
            }
            if (checkBoxHamgurguer.Checked)
            {
                mostrar += checkBoxHamgurguer.Text + ", ";
            }
            if (checkBoxJaponesa.Checked)
            {
                mostrar += checkBoxJaponesa.Text + ", ";
            }
            if (checkBoxMassas.Checked)
            {
                mostrar += checkBoxMassas.Text + ", ";
            }
            if (checkBoxSobremessas.Checked)
            {
                mostrar += checkBoxSobremessas.Text + ", ";
            }
            if (checkBoxChurrasco.Checked)
            {
                mostrar += checkBoxChurrasco.Text + "";
            }
            MessageBox.Show(mostrar,"Opções Favoritadas ", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }
    }
}
