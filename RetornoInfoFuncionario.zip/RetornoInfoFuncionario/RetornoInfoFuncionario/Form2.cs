﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RetornoInfoFuncionario.Classe;
using RetornoInfoFuncionario;

namespace RetornoInfoFuncionario
{
    public partial class Form2 : Form
    {
        public Funcionario funcionario = new Funcionario();


        public Form2()
        {
            InitializeComponent();
        }

        private void buttonCadastrar_Click(object sender, EventArgs e)
        {
            //Funcionario funcionario = new Funcionario();

            funcionario.Nome = textBoxNome.Text;
            funcionario.CPF = textBoxCPF.Text;
            funcionario.Empresa = comboBoxEmpresa.Text;

            this.Close();


        }

        private void buttonEmpresa_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.ShowDialog();

            string NomeDaEmpresaCadastrada = form3.NomeDaEmpresa;

            Empresa.Empresas.Add(NomeDaEmpresaCadastrada);

            comboBoxEmpresa.DataSource = null;
            comboBoxEmpresa.DataSource = Empresa.Empresas;



        }

        private void Form2_Load(object sender, EventArgs e)
        {
            comboBoxEmpresa.DataSource = null;
            comboBoxEmpresa.DataSource = Empresa.Empresas;
        }
    }
}
