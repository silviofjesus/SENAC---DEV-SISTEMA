﻿namespace Desafios
{
    partial class Desafio02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelNumerodaConta = new System.Windows.Forms.Label();
            this.textBoxNumerodaConta = new System.Windows.Forms.TextBox();
            this.textBoxDepositar = new System.Windows.Forms.TextBox();
            this.buttonDepositar = new System.Windows.Forms.Button();
            this.textBoxSacar = new System.Windows.Forms.TextBox();
            this.buttonSacar = new System.Windows.Forms.Button();
            this.labelSaldo = new System.Windows.Forms.Label();
            this.labelValoratual = new System.Windows.Forms.Label();
            this.labelInternetBank = new System.Windows.Forms.Label();
            this.buttonEntrar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelNumerodaConta
            // 
            this.labelNumerodaConta.AutoSize = true;
            this.labelNumerodaConta.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelNumerodaConta.Location = new System.Drawing.Point(40, 91);
            this.labelNumerodaConta.Name = "labelNumerodaConta";
            this.labelNumerodaConta.Size = new System.Drawing.Size(143, 19);
            this.labelNumerodaConta.TabIndex = 0;
            this.labelNumerodaConta.Text = "Numero da Conta";
            // 
            // textBoxNumerodaConta
            // 
            this.textBoxNumerodaConta.Location = new System.Drawing.Point(40, 113);
            this.textBoxNumerodaConta.Name = "textBoxNumerodaConta";
            this.textBoxNumerodaConta.Size = new System.Drawing.Size(143, 23);
            this.textBoxNumerodaConta.TabIndex = 1;
            // 
            // textBoxDepositar
            // 
            this.textBoxDepositar.Location = new System.Drawing.Point(41, 157);
            this.textBoxDepositar.Name = "textBoxDepositar";
            this.textBoxDepositar.Size = new System.Drawing.Size(142, 23);
            this.textBoxDepositar.TabIndex = 2;
            // 
            // buttonDepositar
            // 
            this.buttonDepositar.Location = new System.Drawing.Point(230, 156);
            this.buttonDepositar.Name = "buttonDepositar";
            this.buttonDepositar.Size = new System.Drawing.Size(75, 23);
            this.buttonDepositar.TabIndex = 3;
            this.buttonDepositar.Text = "Depositar";
            this.buttonDepositar.UseVisualStyleBackColor = true;
            this.buttonDepositar.Click += new System.EventHandler(this.buttonDepositar_Click);
            // 
            // textBoxSacar
            // 
            this.textBoxSacar.Location = new System.Drawing.Point(40, 186);
            this.textBoxSacar.Name = "textBoxSacar";
            this.textBoxSacar.Size = new System.Drawing.Size(143, 23);
            this.textBoxSacar.TabIndex = 4;
            // 
            // buttonSacar
            // 
            this.buttonSacar.Location = new System.Drawing.Point(230, 186);
            this.buttonSacar.Name = "buttonSacar";
            this.buttonSacar.Size = new System.Drawing.Size(75, 23);
            this.buttonSacar.TabIndex = 5;
            this.buttonSacar.Text = "Sacar";
            this.buttonSacar.UseVisualStyleBackColor = true;
            this.buttonSacar.Click += new System.EventHandler(this.buttonSacar_Click);
            // 
            // labelSaldo
            // 
            this.labelSaldo.AutoSize = true;
            this.labelSaldo.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelSaldo.Location = new System.Drawing.Point(230, 91);
            this.labelSaldo.Name = "labelSaldo";
            this.labelSaldo.Size = new System.Drawing.Size(78, 19);
            this.labelSaldo.TabIndex = 6;
            this.labelSaldo.Text = "Saldo R$";
            // 
            // labelValoratual
            // 
            this.labelValoratual.AutoSize = true;
            this.labelValoratual.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelValoratual.Location = new System.Drawing.Point(323, 91);
            this.labelValoratual.Name = "labelValoratual";
            this.labelValoratual.Size = new System.Drawing.Size(40, 19);
            this.labelValoratual.TabIndex = 7;
            this.labelValoratual.Text = "0,00";
            // 
            // labelInternetBank
            // 
            this.labelInternetBank.AutoSize = true;
            this.labelInternetBank.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelInternetBank.Location = new System.Drawing.Point(106, 24);
            this.labelInternetBank.Name = "labelInternetBank";
            this.labelInternetBank.Size = new System.Drawing.Size(135, 19);
            this.labelInternetBank.TabIndex = 8;
            this.labelInternetBank.Text = "Internet Banking";
            // 
            // buttonEntrar
            // 
            this.buttonEntrar.Location = new System.Drawing.Point(189, 113);
            this.buttonEntrar.Name = "buttonEntrar";
            this.buttonEntrar.Size = new System.Drawing.Size(52, 23);
            this.buttonEntrar.TabIndex = 9;
            this.buttonEntrar.Text = "Entrar";
            this.buttonEntrar.UseVisualStyleBackColor = true;
            this.buttonEntrar.Click += new System.EventHandler(this.buttonEntrar_Click);
            // 
            // Desafio02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(373, 273);
            this.Controls.Add(this.buttonEntrar);
            this.Controls.Add(this.labelInternetBank);
            this.Controls.Add(this.labelValoratual);
            this.Controls.Add(this.labelSaldo);
            this.Controls.Add(this.buttonSacar);
            this.Controls.Add(this.textBoxSacar);
            this.Controls.Add(this.buttonDepositar);
            this.Controls.Add(this.textBoxDepositar);
            this.Controls.Add(this.textBoxNumerodaConta);
            this.Controls.Add(this.labelNumerodaConta);
            this.Name = "Desafio02";
            this.Text = "Desafio02";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label labelNumerodaConta;
        private TextBox textBoxNumerodaConta;
        private TextBox textBoxDepositar;
        private Button buttonDepositar;
        private TextBox textBoxSacar;
        private Button buttonSacar;
        private Label labelSaldo;
        private Label labelValoratual;
        private Label labelInternetBank;
        private Button buttonEntrar;
    }
}