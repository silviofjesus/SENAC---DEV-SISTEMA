﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IMC;

namespace IMC.Classe
{
    public class Pessoa
    {
        public double Peso { get; set; }
        public double Altura { get; set; }

    }
}
