﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DadosCompartilhados
{
    public static class ClasseDadosCompartilhados
    {

        public static string DadosCompartilhados { get; set; }


    }
}
