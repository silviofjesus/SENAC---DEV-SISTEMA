﻿namespace AdicionarElementos
{
    partial class InverterLista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonAdicionar = new Button();
            textBoxAdicionar = new TextBox();
            buttonExibir = new Button();
            buttonInverter = new Button();
            SuspendLayout();
            // 
            // buttonAdicionar
            // 
            buttonAdicionar.Location = new Point(39, 57);
            buttonAdicionar.Name = "buttonAdicionar";
            buttonAdicionar.Size = new Size(75, 23);
            buttonAdicionar.TabIndex = 0;
            buttonAdicionar.Text = "Adicionar";
            buttonAdicionar.UseVisualStyleBackColor = true;
            buttonAdicionar.Click += buttonAdicionar_Click;
            // 
            // textBoxAdicionar
            // 
            textBoxAdicionar.Location = new Point(120, 58);
            textBoxAdicionar.Name = "textBoxAdicionar";
            textBoxAdicionar.Size = new Size(100, 23);
            textBoxAdicionar.TabIndex = 1;
            // 
            // buttonExibir
            // 
            buttonExibir.Location = new Point(39, 98);
            buttonExibir.Name = "buttonExibir";
            buttonExibir.Size = new Size(75, 23);
            buttonExibir.TabIndex = 2;
            buttonExibir.Text = "Exibir";
            buttonExibir.UseVisualStyleBackColor = true;
            buttonExibir.Click += buttonExibir_Click;
            // 
            // buttonInverter
            // 
            buttonInverter.Location = new Point(39, 137);
            buttonInverter.Name = "buttonInverter";
            buttonInverter.Size = new Size(75, 23);
            buttonInverter.TabIndex = 3;
            buttonInverter.Text = "Inverter";
            buttonInverter.UseVisualStyleBackColor = true;
            buttonInverter.Click += buttonInverter_Click;
            // 
            // InverterLista
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(buttonInverter);
            Controls.Add(buttonExibir);
            Controls.Add(textBoxAdicionar);
            Controls.Add(buttonAdicionar);
            Name = "InverterLista";
            Text = "InverterLista";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonAdicionar;
        private TextBox textBoxAdicionar;
        private Button buttonExibir;
        private Button buttonInverter;
    }
}