﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdicionarElementos
{
   
    public partial class SubstituirElementos : Form
    {

        List<string> substituirElementos = new List<string> { "1","2","3","4","5","6","7","8","9","10" };

        public SubstituirElementos()
        {
            InitializeComponent();
        }

        private void buttonAdicionar_Click(object sender, EventArgs e)
        {
            string adicionar = textBoxAdicionar.Text;
            substituirElementos.Add(adicionar);
            textBoxAdicionar.Text = "";


        }

        private void buttonExibir_Click(object sender, EventArgs e)
        {
            string exibir = "";

            foreach (var item in substituirElementos)
            {
                exibir += item + "\n";
            }

            MessageBox.Show(exibir);
        }

        private void buttonExibir2_Click(object sender, EventArgs e)
        {
            string exibir2 = "";

            foreach (var item in substituirElementos)
            {
                exibir2 += item + "\n";
            }

            MessageBox.Show(exibir2);
        }

        private void buttonSubstituir_Click(object sender, EventArgs e)
        {
            string novoelemento = textBoxSubstituir.Text;
            string novoindice = Convert.ToString(numericUpDownSubstIndice.Value);

            substituirElementos[Convert.ToInt32(novoindice)] = novoelemento;

            textBoxSubstituir.Text = "";
           
        }
    }
}
