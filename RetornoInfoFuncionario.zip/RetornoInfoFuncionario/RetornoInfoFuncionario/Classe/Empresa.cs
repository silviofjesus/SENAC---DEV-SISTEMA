﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetornoInfoFuncionario.Classe
{
    public static class Empresa
    {
        public static List <string> Empresas  = new List <string> ();
        
    }
}
