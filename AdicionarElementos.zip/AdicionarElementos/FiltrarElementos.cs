﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdicionarElementos
{
    public partial class FiltrarElementos : Form
    {
        List<string> nomes = new List<string>();

        public FiltrarElementos()
        {
            InitializeComponent();
        }

        private void buttonAdicionar_Click(object sender, EventArgs e)
        {
            string adicionar = textBoxAdiconar.Text;

            nomes.Add(adicionar);

            textBoxAdiconar.Text = "";

        }

        private void buttonExibir_Click(object sender, EventArgs e)
        {
            string exibir = "";

            foreach (var item in nomes)
            {
                exibir += item + "\n";
            }

            MessageBox.Show(exibir);


        }

        private void buttonPesquisar_Click(object sender, EventArgs e)
        {
            string pesquisar = textBoxPesquisar.Text;

            textBoxPesquisar.Text = "";

            string exibirResultado = "";

            List<string> pesquisarnomes = nomes.FindAll(x => x.Contains(pesquisar));

            foreach (var item in pesquisarnomes)
            {
                exibirResultado += item + "\n";
            }

            if (pesquisar == string.Empty)
            {

            }

            MessageBox.Show(exibirResultado);
            
        }
       
    }
}
