﻿namespace RetornoInfoFuncionario
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelNomedaEmpresa = new System.Windows.Forms.Label();
            this.comboBoxEmpresa = new System.Windows.Forms.ComboBox();
            this.buttonCadastrarEmpresa = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelNomedaEmpresa
            // 
            this.labelNomedaEmpresa.AutoSize = true;
            this.labelNomedaEmpresa.Location = new System.Drawing.Point(49, 65);
            this.labelNomedaEmpresa.Name = "labelNomedaEmpresa";
            this.labelNomedaEmpresa.Size = new System.Drawing.Size(115, 15);
            this.labelNomedaEmpresa.TabIndex = 2;
            this.labelNomedaEmpresa.Text = "NOME DA EMPRESA";
            // 
            // comboBoxEmpresa
            // 
            this.comboBoxEmpresa.FormattingEnabled = true;
            this.comboBoxEmpresa.Location = new System.Drawing.Point(51, 83);
            this.comboBoxEmpresa.Name = "comboBoxEmpresa";
            this.comboBoxEmpresa.Size = new System.Drawing.Size(259, 23);
            this.comboBoxEmpresa.TabIndex = 5;
            // 
            // buttonCadastrarEmpresa
            // 
            this.buttonCadastrarEmpresa.Location = new System.Drawing.Point(51, 216);
            this.buttonCadastrarEmpresa.Name = "buttonCadastrarEmpresa";
            this.buttonCadastrarEmpresa.Size = new System.Drawing.Size(259, 54);
            this.buttonCadastrarEmpresa.TabIndex = 6;
            this.buttonCadastrarEmpresa.Text = "Cadastrar Empresa";
            this.buttonCadastrarEmpresa.UseVisualStyleBackColor = true;
            this.buttonCadastrarEmpresa.Click += new System.EventHandler(this.buttonCadastrarEmpresa_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(368, 325);
            this.Controls.Add(this.buttonCadastrarEmpresa);
            this.Controls.Add(this.comboBoxEmpresa);
            this.Controls.Add(this.labelNomedaEmpresa);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Label labelNomedaEmpresa;
        private ComboBox comboBoxEmpresa;
        private Button buttonCadastrarEmpresa;
    }
}