﻿namespace Desafios
{
    partial class Desafio03
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelNome = new Label();
            textBoxNome = new TextBox();
            textBoxCPF = new TextBox();
            labelCPF = new Label();
            labelEstado = new Label();
            labelCidade = new Label();
            textBoxCidade = new TextBox();
            comboBoxEstado = new ComboBox();
            label1 = new Label();
            textBoxRua = new TextBox();
            textBoxNumero = new TextBox();
            labelNumero = new Label();
            label2 = new Label();
            checkBoxPizza = new CheckBox();
            checkBoxHamgurguer = new CheckBox();
            checkBoxJaponesa = new CheckBox();
            checkBoxMassas = new CheckBox();
            checkBoxSobremessas = new CheckBox();
            checkBoxChurrasco = new CheckBox();
            button1 = new Button();
            SuspendLayout();
            // 
            // labelNome
            // 
            labelNome.AutoSize = true;
            labelNome.Location = new Point(30, 45);
            labelNome.Name = "labelNome";
            labelNome.Size = new Size(40, 15);
            labelNome.TabIndex = 0;
            labelNome.Text = "Nome";
            // 
            // textBoxNome
            // 
            textBoxNome.Location = new Point(30, 62);
            textBoxNome.Name = "textBoxNome";
            textBoxNome.Size = new Size(243, 23);
            textBoxNome.TabIndex = 1;
            // 
            // textBoxCPF
            // 
            textBoxCPF.Location = new Point(279, 62);
            textBoxCPF.Name = "textBoxCPF";
            textBoxCPF.Size = new Size(100, 23);
            textBoxCPF.TabIndex = 2;
            // 
            // labelCPF
            // 
            labelCPF.AutoSize = true;
            labelCPF.Location = new Point(279, 45);
            labelCPF.Name = "labelCPF";
            labelCPF.Size = new Size(28, 15);
            labelCPF.TabIndex = 3;
            labelCPF.Text = "CPF";
            // 
            // labelEstado
            // 
            labelEstado.AutoSize = true;
            labelEstado.Location = new Point(27, 101);
            labelEstado.Name = "labelEstado";
            labelEstado.Size = new Size(42, 15);
            labelEstado.TabIndex = 4;
            labelEstado.Text = "Estado";
            // 
            // labelCidade
            // 
            labelCidade.AutoSize = true;
            labelCidade.Location = new Point(279, 101);
            labelCidade.Name = "labelCidade";
            labelCidade.Size = new Size(44, 15);
            labelCidade.TabIndex = 5;
            labelCidade.Text = "Cidade";
            // 
            // textBoxCidade
            // 
            textBoxCidade.Location = new Point(279, 119);
            textBoxCidade.Name = "textBoxCidade";
            textBoxCidade.Size = new Size(100, 23);
            textBoxCidade.TabIndex = 7;
            // 
            // comboBoxEstado
            // 
            comboBoxEstado.FormattingEnabled = true;
            comboBoxEstado.Items.AddRange(new object[] { "ES", "RJ", "SP", "MG" });
            comboBoxEstado.Location = new Point(30, 119);
            comboBoxEstado.Name = "comboBoxEstado";
            comboBoxEstado.Size = new Size(243, 23);
            comboBoxEstado.TabIndex = 8;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(30, 156);
            label1.Name = "label1";
            label1.Size = new Size(27, 15);
            label1.TabIndex = 9;
            label1.Text = "Rua";
            // 
            // textBoxRua
            // 
            textBoxRua.Location = new Point(30, 174);
            textBoxRua.Name = "textBoxRua";
            textBoxRua.Size = new Size(243, 23);
            textBoxRua.TabIndex = 10;
            // 
            // textBoxNumero
            // 
            textBoxNumero.Location = new Point(279, 174);
            textBoxNumero.Name = "textBoxNumero";
            textBoxNumero.Size = new Size(100, 23);
            textBoxNumero.TabIndex = 11;
            // 
            // labelNumero
            // 
            labelNumero.AutoSize = true;
            labelNumero.Location = new Point(279, 156);
            labelNumero.Name = "labelNumero";
            labelNumero.Size = new Size(51, 15);
            labelNumero.TabIndex = 12;
            labelNumero.Text = "Numero";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(30, 220);
            label2.Name = "label2";
            label2.Size = new Size(104, 15);
            label2.TabIndex = 13;
            label2.Text = "Comidas Favoritas";
            // 
            // checkBoxPizza
            // 
            checkBoxPizza.AutoSize = true;
            checkBoxPizza.Location = new Point(27, 245);
            checkBoxPizza.Name = "checkBoxPizza";
            checkBoxPizza.Size = new Size(52, 19);
            checkBoxPizza.TabIndex = 14;
            checkBoxPizza.Text = "Pizza";
            checkBoxPizza.UseVisualStyleBackColor = true;
            // 
            // checkBoxHamgurguer
            // 
            checkBoxHamgurguer.AutoSize = true;
            checkBoxHamgurguer.Location = new Point(27, 275);
            checkBoxHamgurguer.Name = "checkBoxHamgurguer";
            checkBoxHamgurguer.Size = new Size(94, 19);
            checkBoxHamgurguer.TabIndex = 15;
            checkBoxHamgurguer.Text = "Hamburguer";
            checkBoxHamgurguer.UseVisualStyleBackColor = true;
            // 
            // checkBoxJaponesa
            // 
            checkBoxJaponesa.AutoSize = true;
            checkBoxJaponesa.Location = new Point(27, 309);
            checkBoxJaponesa.Name = "checkBoxJaponesa";
            checkBoxJaponesa.Size = new Size(74, 19);
            checkBoxJaponesa.TabIndex = 16;
            checkBoxJaponesa.Text = "Japonesa";
            checkBoxJaponesa.UseVisualStyleBackColor = true;
            // 
            // checkBoxMassas
            // 
            checkBoxMassas.AutoSize = true;
            checkBoxMassas.Location = new Point(178, 245);
            checkBoxMassas.Name = "checkBoxMassas";
            checkBoxMassas.Size = new Size(64, 19);
            checkBoxMassas.TabIndex = 17;
            checkBoxMassas.Text = "Massas";
            checkBoxMassas.UseVisualStyleBackColor = true;
            // 
            // checkBoxSobremessas
            // 
            checkBoxSobremessas.AutoSize = true;
            checkBoxSobremessas.Location = new Point(178, 275);
            checkBoxSobremessas.Name = "checkBoxSobremessas";
            checkBoxSobremessas.Size = new Size(94, 19);
            checkBoxSobremessas.TabIndex = 18;
            checkBoxSobremessas.Text = "Sobremessas";
            checkBoxSobremessas.UseVisualStyleBackColor = true;
            // 
            // checkBoxChurrasco
            // 
            checkBoxChurrasco.AutoSize = true;
            checkBoxChurrasco.Location = new Point(178, 309);
            checkBoxChurrasco.Name = "checkBoxChurrasco";
            checkBoxChurrasco.Size = new Size(80, 19);
            checkBoxChurrasco.TabIndex = 19;
            checkBoxChurrasco.Text = "Churrasco";
            checkBoxChurrasco.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Location = new Point(304, 261);
            button1.Name = "button1";
            button1.Size = new Size(75, 45);
            button1.TabIndex = 20;
            button1.Text = "Imprimir Detalhes";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Desafio03
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(427, 387);
            Controls.Add(button1);
            Controls.Add(checkBoxChurrasco);
            Controls.Add(checkBoxSobremessas);
            Controls.Add(checkBoxMassas);
            Controls.Add(checkBoxJaponesa);
            Controls.Add(checkBoxHamgurguer);
            Controls.Add(checkBoxPizza);
            Controls.Add(label2);
            Controls.Add(labelNumero);
            Controls.Add(textBoxNumero);
            Controls.Add(textBoxRua);
            Controls.Add(label1);
            Controls.Add(comboBoxEstado);
            Controls.Add(textBoxCidade);
            Controls.Add(labelCidade);
            Controls.Add(labelEstado);
            Controls.Add(labelCPF);
            Controls.Add(textBoxCPF);
            Controls.Add(textBoxNome);
            Controls.Add(labelNome);
            Name = "Desafio03";
            Text = "Desafio03";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelNome;
        private TextBox textBoxNome;
        private TextBox textBoxCPF;
        private Label labelCPF;
        private Label labelEstado;
        private Label labelCidade;
        private TextBox textBoxCidade;
        private ComboBox comboBoxEstado;
        private Label label1;
        private TextBox textBoxRua;
        private TextBox textBoxNumero;
        private Label labelNumero;
        private Label label2;
        private CheckBox checkBoxPizza;
        private CheckBox checkBoxHamgurguer;
        private CheckBox checkBoxJaponesa;
        private CheckBox checkBoxMassas;
        private CheckBox checkBoxSobremessas;
        private CheckBox checkBoxChurrasco;
        private Button button1;
    }
}