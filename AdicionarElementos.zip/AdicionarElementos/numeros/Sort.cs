﻿namespace numeros
{
    internal class Sort
    {
    }
}