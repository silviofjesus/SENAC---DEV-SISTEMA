﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio02.Classes
{
    public class Pessoa
    {
        public string Nome { get; set; }
        public int Idade { get; set; }

        public Pessoa( string nome, int idade)
        {
            this.Nome = nome;
            this.Idade = idade;
        }

        public void detalhes()
        {
            Console.WriteLine("Nome: " + Nome + " Idade: " + Idade);
            apresentar();
        }
        public void apresentar()
        {
            Console.WriteLine("Ola, meu nome é " + Nome + " tenho a idade de " + Idade + " anos.");
        }



    }
}
