﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio02.Classes
{
    public class ContaBancaria
    {
        public double Conta { get; set; }
        public double Saldo { get; set;}

        public ContaBancaria(double conta, double saldo)
        {
            Conta = conta;
            Saldo = saldo;
        }

        public void Depositar( double valor)
        {
            Saldo = Saldo + valor;
            Console.WriteLine(Saldo);
        }

        public void Sacar(double valor)
        {
            if (Consultar(valor) == true)
            {
                Saldo = Saldo - valor;
                Console.WriteLine(Saldo);
            }
            else
            {
                Console.WriteLine("O valor de saque é maior que o Saldo.");
            }
            
        }

        private bool Consultar (double valor)
        {
            if(valor <= Saldo)
            {
                return true;
            }else
                return false;

        }

    }
}
