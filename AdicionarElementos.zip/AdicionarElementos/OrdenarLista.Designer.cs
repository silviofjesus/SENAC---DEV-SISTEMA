﻿namespace AdicionarElementos
{
    partial class OrdenarLista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonAdicionarAleatorio = new System.Windows.Forms.Button();
            this.buttonOrdemCrescente = new System.Windows.Forms.Button();
            this.textBoxAdicionarAleatorio = new System.Windows.Forms.TextBox();
            this.buttonOrdemDecrescente = new System.Windows.Forms.Button();
            this.buttonExibir = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonAdicionarAleatorio
            // 
            this.buttonAdicionarAleatorio.Location = new System.Drawing.Point(71, 68);
            this.buttonAdicionarAleatorio.Name = "buttonAdicionarAleatorio";
            this.buttonAdicionarAleatorio.Size = new System.Drawing.Size(142, 23);
            this.buttonAdicionarAleatorio.TabIndex = 0;
            this.buttonAdicionarAleatorio.Text = "Adicionar Aleatorio";
            this.buttonAdicionarAleatorio.UseVisualStyleBackColor = true;
            this.buttonAdicionarAleatorio.Click += new System.EventHandler(this.buttonAdicionarAleatorio_Click);
            // 
            // buttonOrdemCrescente
            // 
            this.buttonOrdemCrescente.Location = new System.Drawing.Point(71, 157);
            this.buttonOrdemCrescente.Name = "buttonOrdemCrescente";
            this.buttonOrdemCrescente.Size = new System.Drawing.Size(142, 23);
            this.buttonOrdemCrescente.TabIndex = 2;
            this.buttonOrdemCrescente.Text = "Ordem Crescente";
            this.buttonOrdemCrescente.UseVisualStyleBackColor = true;
            this.buttonOrdemCrescente.Click += new System.EventHandler(this.buttonOrdemCrescente_Click);
            // 
            // textBoxAdicionarAleatorio
            // 
            this.textBoxAdicionarAleatorio.Location = new System.Drawing.Point(219, 68);
            this.textBoxAdicionarAleatorio.Name = "textBoxAdicionarAleatorio";
            this.textBoxAdicionarAleatorio.Size = new System.Drawing.Size(145, 23);
            this.textBoxAdicionarAleatorio.TabIndex = 3;
            // 
            // buttonOrdemDecrescente
            // 
            this.buttonOrdemDecrescente.Location = new System.Drawing.Point(71, 199);
            this.buttonOrdemDecrescente.Name = "buttonOrdemDecrescente";
            this.buttonOrdemDecrescente.Size = new System.Drawing.Size(142, 23);
            this.buttonOrdemDecrescente.TabIndex = 4;
            this.buttonOrdemDecrescente.Text = "Ordem Decrescente";
            this.buttonOrdemDecrescente.UseVisualStyleBackColor = true;
            this.buttonOrdemDecrescente.Click += new System.EventHandler(this.buttonOrdemDecrescente_Click);
            // 
            // buttonExibir
            // 
            this.buttonExibir.Location = new System.Drawing.Point(71, 111);
            this.buttonExibir.Name = "buttonExibir";
            this.buttonExibir.Size = new System.Drawing.Size(142, 23);
            this.buttonExibir.TabIndex = 5;
            this.buttonExibir.Text = "Exibir";
            this.buttonExibir.UseVisualStyleBackColor = true;
            this.buttonExibir.Click += new System.EventHandler(this.buttonExibir_Click);
            // 
            // OrdenarLista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(533, 289);
            this.Controls.Add(this.buttonExibir);
            this.Controls.Add(this.buttonOrdemDecrescente);
            this.Controls.Add(this.textBoxAdicionarAleatorio);
            this.Controls.Add(this.buttonOrdemCrescente);
            this.Controls.Add(this.buttonAdicionarAleatorio);
            this.Name = "OrdenarLista";
            this.Text = "OrdenarLista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button buttonAdicionarAleatorio;
        private Button buttonOrdemCrescente;
        private TextBox textBoxAdicionarAleatorio;
        private Button buttonOrdemDecrescente;
        private Button buttonExibir;
    }
}