﻿namespace AdicionarElementos
{
    partial class AdicionarElementos
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBoxAdicionar = new TextBox();
            buttonAdicionar = new Button();
            buttonExibir = new Button();
            SuspendLayout();
            // 
            // textBoxAdicionar
            // 
            textBoxAdicionar.Location = new Point(53, 59);
            textBoxAdicionar.Name = "textBoxAdicionar";
            textBoxAdicionar.Size = new Size(179, 23);
            textBoxAdicionar.TabIndex = 0;
            // 
            // buttonAdicionar
            // 
            buttonAdicionar.Location = new Point(238, 59);
            buttonAdicionar.Name = "buttonAdicionar";
            buttonAdicionar.Size = new Size(75, 23);
            buttonAdicionar.TabIndex = 1;
            buttonAdicionar.Text = "Adicionar";
            buttonAdicionar.UseVisualStyleBackColor = true;
            buttonAdicionar.Click += buttonAdicionar_Click;
            // 
            // buttonExibir
            // 
            buttonExibir.Location = new Point(238, 88);
            buttonExibir.Name = "buttonExibir";
            buttonExibir.Size = new Size(75, 23);
            buttonExibir.TabIndex = 2;
            buttonExibir.Text = "Exibir";
            buttonExibir.UseVisualStyleBackColor = true;
            buttonExibir.Click += buttonExibir_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(374, 176);
            Controls.Add(buttonExibir);
            Controls.Add(buttonAdicionar);
            Controls.Add(textBoxAdicionar);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBoxAdicionar;
        private Button buttonAdicionar;
        private Button buttonExibir;
    }
}