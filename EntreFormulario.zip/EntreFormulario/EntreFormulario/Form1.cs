namespace EntreFormulario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonForm2_Click(object sender, EventArgs e)
        {

            Form2 objForm2 = new Form2();


            objForm2.msg = "teste";
            objForm2.ShowDialog();
        }
    }
}