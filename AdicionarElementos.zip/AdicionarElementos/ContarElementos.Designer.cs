﻿namespace AdicionarElementos
{
    partial class ContarElementos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonAdicionar = new System.Windows.Forms.Button();
            this.textBoxAdicionar = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.buttonExibir = new System.Windows.Forms.Button();
            this.textBoxContarElementos = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // buttonAdicionar
            // 
            this.buttonAdicionar.Location = new System.Drawing.Point(45, 57);
            this.buttonAdicionar.Name = "buttonAdicionar";
            this.buttonAdicionar.Size = new System.Drawing.Size(114, 23);
            this.buttonAdicionar.TabIndex = 0;
            this.buttonAdicionar.Text = "Adicionar";
            this.buttonAdicionar.UseVisualStyleBackColor = true;
            this.buttonAdicionar.Click += new System.EventHandler(this.buttonAdicionar_Click);
            // 
            // textBoxAdicionar
            // 
            this.textBoxAdicionar.Location = new System.Drawing.Point(165, 57);
            this.textBoxAdicionar.Name = "textBoxAdicionar";
            this.textBoxAdicionar.Size = new System.Drawing.Size(154, 23);
            this.textBoxAdicionar.TabIndex = 1;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(45, 103);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(114, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "Contar Elementos";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // buttonExibir
            // 
            this.buttonExibir.Location = new System.Drawing.Point(325, 57);
            this.buttonExibir.Name = "buttonExibir";
            this.buttonExibir.Size = new System.Drawing.Size(75, 23);
            this.buttonExibir.TabIndex = 3;
            this.buttonExibir.Text = "Exibir";
            this.buttonExibir.UseVisualStyleBackColor = true;
            this.buttonExibir.Click += new System.EventHandler(this.buttonExibir_Click);
            // 
            // textBoxContarElementos
            // 
            this.textBoxContarElementos.Location = new System.Drawing.Point(165, 103);
            this.textBoxContarElementos.Name = "textBoxContarElementos";
            this.textBoxContarElementos.Size = new System.Drawing.Size(154, 23);
            this.textBoxContarElementos.TabIndex = 4;
            // 
            // ContarElementos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBoxContarElementos);
            this.Controls.Add(this.buttonExibir);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBoxAdicionar);
            this.Controls.Add(this.buttonAdicionar);
            this.Name = "ContarElementos";
            this.Text = "ContarElementos";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button buttonAdicionar;
        private TextBox textBoxAdicionar;
        private Button button2;
        private Button buttonExibir;
        private TextBox textBoxContarElementos;
    }
}