﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdicionarElementos
{
    public partial class SomarElementos : Form
    {
        List<int> numeros =new List<int>();


        public SomarElementos()
        {
            InitializeComponent();
        }

        private void buttonAdicionar_Click(object sender, EventArgs e)
        {
            int adicionar = Convert.ToInt32(textBoxAdicionar.Text);
            numeros.Add(adicionar);
            textBoxAdicionar.Text = "";

        }

        private void buttonSomarElementos_Click(object sender, EventArgs e)
        {
            int somarElementos = 0;

            int resultado = numeros.Sum();


            foreach (var item in numeros) // com metodo FORECH
            {
                somarElementos += item;
            }
            MessageBox.Show(Convert.ToString(somarElementos));

            MessageBox.Show(Convert.ToString(resultado));
        }
    }
}
