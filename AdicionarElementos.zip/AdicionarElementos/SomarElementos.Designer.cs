﻿namespace AdicionarElementos
{
    partial class SomarElementos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxAdicionar = new System.Windows.Forms.TextBox();
            this.buttonAdicionar = new System.Windows.Forms.Button();
            this.buttonSomarElementos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBoxAdicionar
            // 
            this.textBoxAdicionar.Location = new System.Drawing.Point(45, 50);
            this.textBoxAdicionar.Name = "textBoxAdicionar";
            this.textBoxAdicionar.Size = new System.Drawing.Size(100, 23);
            this.textBoxAdicionar.TabIndex = 0;
            // 
            // buttonAdicionar
            // 
            this.buttonAdicionar.Location = new System.Drawing.Point(151, 50);
            this.buttonAdicionar.Name = "buttonAdicionar";
            this.buttonAdicionar.Size = new System.Drawing.Size(75, 23);
            this.buttonAdicionar.TabIndex = 1;
            this.buttonAdicionar.Text = "Adicionar";
            this.buttonAdicionar.UseVisualStyleBackColor = true;
            this.buttonAdicionar.Click += new System.EventHandler(this.buttonAdicionar_Click);
            // 
            // buttonSomarElementos
            // 
            this.buttonSomarElementos.Location = new System.Drawing.Point(232, 50);
            this.buttonSomarElementos.Name = "buttonSomarElementos";
            this.buttonSomarElementos.Size = new System.Drawing.Size(127, 23);
            this.buttonSomarElementos.TabIndex = 2;
            this.buttonSomarElementos.Text = "Somar Elementos";
            this.buttonSomarElementos.UseVisualStyleBackColor = true;
            this.buttonSomarElementos.Click += new System.EventHandler(this.buttonSomarElementos_Click);
            // 
            // SomarElementos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonSomarElementos);
            this.Controls.Add(this.buttonAdicionar);
            this.Controls.Add(this.textBoxAdicionar);
            this.Name = "SomarElementos";
            this.Text = "SomarElementos";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox textBoxAdicionar;
        private Button buttonAdicionar;
        private Button buttonSomarElementos;
    }
}