﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdicionarElementos
{
    public partial class Remover_Elementos : Form
    {
        List<string> nomes = new List<string> { "silvio", "Elis" };


        public Remover_Elementos()
        {
            InitializeComponent();
        }

        private void buttonExibir_Click(object sender, EventArgs e)
        {
            string exibir = "";

            foreach (var item in nomes)
            {
                exibir += item + "\n";
            }
            


            MessageBox.Show(exibir);
        }

        private void buttonRemover_Click(object sender, EventArgs e)
        {
            string remover = textBoxremover.Text;

            nomes.Remove(remover);

            nomes.RemoveAll(x => x == remover);

            MessageBox.Show("Remoção", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);

            textBoxremover.Text = "";


        }
    }
}

    