using IMC.Classe;


namespace IMC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void buttonResultado_Click(object sender, EventArgs e)
        {
          Pessoa pessoa = new Pessoa();

            pessoa.Peso = Convert.ToDouble(textBoxPeso.Text);
            pessoa.Altura = Convert.ToDouble(textBoxAltura.Text);
            
            Form2 form2 = new Form2(pessoa);
            form2.ShowDialog();

            textBoxPeso.Text = "";
            textBoxAltura.Text = "";
        }
    }
}