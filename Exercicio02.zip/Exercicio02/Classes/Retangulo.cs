﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio02.Classes
{
    public class Retangulo
    {
        //encapsulamento
        public double Comprimento { get; set; }
        public double Largura { get; set; }

        //metodos construtores
        public Retangulo(double comprimento, double largura)
        {
            this.Comprimento = comprimento;
            this.Largura = largura;
        }
    }
}
