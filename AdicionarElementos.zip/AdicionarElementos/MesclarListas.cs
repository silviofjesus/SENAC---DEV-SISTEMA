﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdicionarElementos
{
    public partial class MesclarListas : Form
    {
        List<int> Lista01 = new List<int> {1,2,3,4,5,6,7,8,9,10 };
        List<int> Lista02 = new List<int> {11,12,13,14,15,16,17,18,19,20 };

        public MesclarListas()
        {
            InitializeComponent();
        }

        private void buttonLista01_Click(object sender, EventArgs e)
        {
            string exibirLista01 = "";

            foreach (var item in Lista01)
            {
                exibirLista01 += item + "\n";
            }

            MessageBox.Show(exibirLista01);
        }

        private void buttonLista02_Click(object sender, EventArgs e)
        {
            string exibirLista02 = "";

            foreach (var item in Lista02)
            {
                exibirLista02 += item + "\n";
            }
            MessageBox.Show(exibirLista02);
        }

        private void buttonMesclarListas_Click(object sender, EventArgs e)
        {
            List<int> Lista03 = new List<int>();

            string mesclarlista = "";

            Lista03.AddRange(Lista01);
            Lista03.AddRange(Lista02);

            foreach (var item in Lista03)
            {
                mesclarlista += item + "\n";
            }

            MessageBox.Show(mesclarlista);



            //string mesclarlista = "";

            //mesclarlista += Convert.ToString(Lista01.Count) + Convert.ToString(Lista02.Count);

            //Lista01.AddRange(Lista01);
            //Lista02.AddRange(Lista02);

            //MessageBox.Show(mesclarlista);


        }
    }
}
