﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdicionarElementos
{
    public partial class OrdenarLista : Form
    {

        List<int> numeros = new List<int>();

        public OrdenarLista()
        {
            InitializeComponent();
        }

        private void buttonAdicionarAleatorio_Click(object sender, EventArgs e)
        {
            int adicionar = Convert.ToInt32(textBoxAdicionarAleatorio.Text);

            numeros.Add(adicionar);


            textBoxAdicionarAleatorio.Text = "";

        }

        private void buttonExibir_Click(object sender, EventArgs e)
        {
            string exibir = "";

            foreach (int i in numeros)

            {
                exibir += i + "\n";
            }

            MessageBox.Show(exibir);
        }

        private void buttonOrdemCrescente_Click(object sender, EventArgs e)
        {
            string crescente = "";

            numeros.Sort();

            foreach (var item in numeros)
            {
                crescente += item + "\n "; 
            }

            MessageBox.Show(crescente);

        }

        private void buttonOrdemDecrescente_Click(object sender, EventArgs e)
        {
            string decrescente = "";

            numeros.Sort();
            numeros.Reverse();


            foreach (var item in numeros)
            {
                decrescente += item + "\n";
            }

            MessageBox.Show(decrescente);

                  
        }
    }
}
