﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdicionarElementos
{
    public partial class TelaPrincipal : Form
    {
        public TelaPrincipal()
        {
            InitializeComponent();
        }

        private void buttonAdicionarElementos_Click(object sender, EventArgs e)
        {
            AdicionarElementos adicionarElementos = new AdicionarElementos();

            adicionarElementos.Show();
        }

        private void buttonRemoverElementos_Click(object sender, EventArgs e)
        {
            Remover_Elementos remover_Elementos = new Remover_Elementos();
            remover_Elementos.Show();
        }

        private void buttonOrdenarLista_Click(object sender, EventArgs e)
        {
            OrdenarLista ordenar_Lista = new OrdenarLista();
            ordenar_Lista.Show();
        }

        private void buttonFiltrarElementos_Click(object sender, EventArgs e)
        {
            FiltrarElementos filtrar_Elementos = new FiltrarElementos();
            filtrar_Elementos.Show();
        }

        private void buttonInverterLista_Click(object sender, EventArgs e)
        {
            InverterLista inverter_Lista = new InverterLista();
            inverter_Lista.Show();
        }

        private void buttonContarElementos_Click(object sender, EventArgs e)
        {
            ContarElementos contar_Elementos = new ContarElementos();
            contar_Elementos.Show();

        }

        private void buttonSomarElementos_Click(object sender, EventArgs e)
        {
            SomarElementos somar_Elementos = new SomarElementos();
            somar_Elementos.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ElementosMinimoMaximo elementosMinimoMaximo = new ElementosMinimoMaximo();
            elementosMinimoMaximo.Show();
        }

        private void buttonSubstituirElementos_Click(object sender, EventArgs e)
        {
            SubstituirElementos substituirElementos = new SubstituirElementos();
            substituirElementos.Show();
        }

        private void buttonMesclarListas_Click(object sender, EventArgs e)
        {
            MesclarListas mesclarListas = new MesclarListas();
            mesclarListas.Show();
        }
    }
}
